import type { MarketHost } from '../routes.ts';
import { type ManagedMarketOptions } from './engine.ts';
export interface LawyerPlatform {
    marketOptions(): ManagedMarketOptions;
    modelStatus(): Promise<unknown>;
    saveCredential(value: string): Promise<void>;
    refreshModels(): Promise<unknown>;
    /**
     * 保存界面提交的模型能力清单（哪些模型可选、每个模型收不收图片）。
     * 只能在本站已开放的模型 id 内做增删与能力声明，不改路由/基址/凭据。
     * 可选：老平台只提供 modelStatus/refreshModels/selectModel，缺这个方法时接口明确报错，
     * 而不是静默当成保存成功。
     */
    saveModels?(models: unknown): Promise<unknown>;
    selectModel(id: string): Promise<void>;
    /**
     * 有序重启工作台。桌面形态由外壳注入（`desktopRuntime.requestRestart()`）；
     * 没有该能力的形态（如 web）返回 false，客户端据此隐藏重启按钮而不是报错。
     */
    restart?(): Promise<boolean>;
}
export declare function mountManagedMarket(host: MarketHost, platform: LawyerPlatform): () => Promise<void>;
