/** Reviewed product-owned plugin source and release pins. */
export interface BuiltinPlugin { readonly packageName: string; readonly version: string; readonly archive: string; readonly upstream: string; readonly fork: string; readonly baseCommit: string }
export const BUILTIN_PLUGINS: readonly BuiltinPlugin[]
export const PRODUCT_BUNDLES: readonly string[]
export const WEB_PRODUCT_BUNDLES: readonly string[]
export const PRODUCT_SEEDS: readonly { readonly packageName: string; readonly archive: string }[]
export const PROTECTED_PACKAGES: readonly string[]
export function composeProductBundles(bundles: unknown, productBundles?: readonly string[]): string[]
