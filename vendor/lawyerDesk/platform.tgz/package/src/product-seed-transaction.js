/** Crash recovery is confined to protected storage and identified directory objects. */
import { randomUUID } from 'node:crypto'
import { lstat, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { basename, dirname, join, resolve } from 'node:path'
export const readJson = async path => JSON.parse(await readFile(path, 'utf8'))
export async function atomicJson(path, value) {
  const temporary = `${path}.${randomUUID()}.tmp`
  try {
    await writeFile(temporary, JSON.stringify(value, null, 2) + '\n', { flag: 'wx', mode: 0o600 })
    await rename(temporary, path)
  } finally { await rm(temporary, { force: true }) }
}
export async function statSafe(path, kind = 'directory') {
  try {
    const stat = await lstat(path)
    if (stat.isSymbolicLink() || (kind === 'directory' ? !stat.isDirectory() : !stat.isFile())) throw new Error('受管产品路径类型异常或包含符号链接')
    return { dev: String(stat.dev), ino: String(stat.ino) }
  } catch (error) { if (error.code === 'ENOENT') return undefined; throw error }
}
const same = (a, b) => !!a && !!b && a.dev === b.dev && a.ino === b.ino
export async function transactionPaths(profile) {
  profile = resolve(profile)
  if (basename(profile) !== 'lawyer' || basename(dirname(profile)) !== 'profiles') throw new Error('无效的受管 profile 路径')
  const home = dirname(dirname(profile)), cache = join(home, 'product-artifacts'), root = join(cache, '.upgrade')
  // The home itself may live below an OS-provided /var symlink; owned descendants may not be symlinks.
  await statSafe(home)
  for (const directory of [dirname(profile), cache, root]) {
    await statSafe(directory)
    await mkdir(directory, { recursive: true, mode: 0o700 })
    await statSafe(directory)
  }
  await statSafe(profile)
  return { home, profile, cache, root, stage: join(root, 'next'), previous: join(root, 'previous'), journal: join(root, 'transaction.json'), lock: join(root, 'operation.lock') }
}
export async function withTransactionLock(paths, operation) {
  if (await statSafe(paths.lock, 'file')) {
    const record = await readJson(paths.lock)
    if (!Number.isSafeInteger(record.pid) || record.pid < 1) throw new Error('产品升级锁无效')
    try { process.kill(record.pid, 0); throw new Error('另一个产品升级操作仍在运行') }
    catch (error) { if (error.code !== 'ESRCH') throw error }
    await rm(paths.lock)
  }
  await writeFile(paths.lock, JSON.stringify({ pid: process.pid }), { flag: 'wx', mode: 0o600 })
  try { return await operation() } finally { await rm(paths.lock) }
}
const identity = value => value && typeof value.dev === 'string' && /^\d+$/.test(value.dev) && typeof value.ino === 'string' && /^\d+$/.test(value.ino)
export async function recoverTransaction(paths, { healthy = false, preserveInstalled = false } = {}) {
  if (!await statSafe(paths.journal, 'file')) return false
  const state = await readJson(paths.journal)
  if (state.schemaVersion !== 1 || typeof state.id !== 'string' || !/^[0-9a-f-]{36}$/.test(state.id) || state.profile !== paths.profile || !['prepared', 'moving', 'installed', 'committed', 'rolling-back'].includes(state.phase) || !identity(state.next) || (state.old !== null && !identity(state.old))) throw new Error('产品升级恢复记录无效；已保留现场')
  const current = await statSafe(paths.profile), stage = await statSafe(paths.stage), previous = await statSafe(paths.previous)
  // Validate the entire snapshot before any rename or deletion, including objects not needed by this phase.
  if ((stage && !same(stage, state.next)) || (previous && !same(previous, state.old)) || (current && !same(current, state.next) && !same(current, state.old))) throw new Error('产品升级目录存在未识别内容；已保留现场')
  const promoted = same(current, state.next)
  if ((promoted && stage) || (same(current, state.old) && previous) || (state.old && !same(current, state.old) && !previous && state.phase !== 'committed')) throw new Error('产品升级状态不一致；已保留现场')
  if (state.phase === 'prepared' && (promoted || previous)) throw new Error('产品升级准备状态不一致；已保留现场')
  if ((state.phase === 'installed' || state.phase === 'committed') && (!promoted || stage)) throw new Error('产品升级切换状态不一致；已保留现场')
  if (preserveInstalled && state.phase === 'installed') return false
  if (healthy && (!promoted || !['installed', 'committed'].includes(state.phase))) throw new Error('产品升级尚未完成切换，不能确认健康')
  if ((healthy || state.phase === 'committed') && promoted) {
    await atomicJson(paths.journal, { ...state, phase: 'committed' })
    if (previous) await rm(paths.previous, { recursive: true })
  } else {
    await atomicJson(paths.journal, { ...state, phase: 'rolling-back' })
    if (promoted) await rename(paths.profile, paths.stage)
    if (previous) await rename(paths.previous, paths.profile)
    if (stage || promoted) await rm(paths.stage, { recursive: true })
  }
  await rm(paths.journal)
  return true
}
/** Recover interrupted filesystem work before resolving packages; retain a fully installed first boot. */
export async function prepareProductSeedsBoot(profile) {
  const paths = await transactionPaths(profile)
  return withTransactionLock(paths, () => recoverTransaction(paths, { preserveInstalled: true }))
}
/** Called only after host/renderer startup has passed its health gate. */
export async function finalizeProductSeeds(profile) {
  const paths = await transactionPaths(profile)
  return withTransactionLock(paths, () => recoverTransaction(paths, { healthy: true }))
}
/** Restore the identified previous environment after a failed first startup. */
export async function rollbackProductSeeds(profile) {
  const paths = await transactionPaths(profile)
  return withTransactionLock(paths, () => recoverTransaction(paths))
}
