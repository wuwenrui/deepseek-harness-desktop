/** Install reviewed product seeds in an isolated profile, then switch at startup. */
import { createHash, randomUUID } from 'node:crypto'
import { existsSync } from 'node:fs'
import { cp, lstat, mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { basename, join } from 'node:path'
import { BUILTIN_PLUGINS, PRODUCT_SEEDS, composeProductBundles } from './builtin-plugins.js'
import { atomicJson, readJson as json, recoverTransaction, statSafe, transactionPaths, withTransactionLock } from './product-seed-transaction.js'
export { finalizeProductSeeds, rollbackProductSeeds, prepareProductSeedsBoot } from './product-seed-transaction.js'
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex')

/** Load built-in byte pins from the shipped inventory; fail before changing any profile. */
export async function productSeedDependencies(seedDirectory, cache) {
  const inventory = await json(join(seedDirectory, 'builtin-plugins.json'))
  if (inventory.schemaVersion !== 1 || !Array.isArray(inventory.plugins)) throw new Error('内置插件清单无效')
  const dependencies = {}
  await statSafe(cache)
  await mkdir(cache, { recursive: true, mode: 0o700 })
  for (const seed of PRODUCT_SEEDS) {
    const bytes = await readFile(join(seedDirectory, seed.archive))
    const digest = sha256(bytes)
    const builtin = BUILTIN_PLUGINS.find(plugin => plugin.packageName === seed.packageName)
    if (builtin) {
      const row = inventory.plugins.find(plugin => plugin.packageName === builtin.packageName)
      if (!row || row.version !== builtin.version || row.archive !== builtin.archive || row.sha256 !== digest || row.size !== bytes.length || row.baseCommit !== builtin.baseCommit) throw new Error(`内置插件制品不匹配：${seed.packageName}`)
    }
    const target = join(cache, `${digest}.tgz`)
    if (!await statSafe(target, 'file')) await writeFile(target, bytes, { flag: 'wx', mode: 0o600 })
    else if (sha256(await readFile(target)) !== digest) throw new Error('产品内置插件缓存校验失败')
    dependencies[seed.packageName] = `file:${target}`
  }
  return dependencies
}

/** Production callers defer finalization until the actual entry has passed its health gate. */
export async function installProductSeeds({ profile, seedDirectory, install, productBundles, deferCommit = false }) {
  const paths = await transactionPaths(profile)
  profile = paths.profile
  return withTransactionLock(paths, async () => {
    await recoverTransaction(paths)
    if (await statSafe(paths.stage) || await statSafe(paths.previous)) throw new Error('产品升级目录存在未识别内容，请保留现场并联系管理员')
    const old = await statSafe(profile)
    const dependencies = await productSeedDependencies(seedDirectory, paths.cache)
    const current = old ? await json(join(profile, 'package.json')) : { name: 'lawyer-managed-profile', private: true, dependencies: {}, dsh: { profile: { bundles: [], patchReload: 'startup' } } }
    const bundles = composeProductBundles(current.dsh?.profile?.bundles, productBundles)
    const next = { ...current, dependencies: { ...current.dependencies, ...dependencies }, dsh: { ...current.dsh, profile: { ...current.dsh?.profile, bundles, patchReload: 'startup' } } }
    if (old && !existsSync(join(profile, '.lawyer-initializing')) && existsSync(join(profile, 'node_modules')) && JSON.stringify(next) === JSON.stringify(current)) return false
    await mkdir(paths.stage, { mode: 0o700 })
    const state = { schemaVersion: 1, id: randomUUID(), profile, phase: 'prepared', old: old ?? null, next: await statSafe(paths.stage) }
    // A crash before the journal is written leaves an unidentified directory: never delete it automatically.
    await atomicJson(paths.journal, state)
    try {
      if (old) {
        await cp(profile, paths.stage, { recursive: true, dereference: false, filter: async path => {
          if (['node_modules', '.lawyer-initializing'].includes(basename(path))) return false
          if ((await lstat(path)).isSymbolicLink()) throw new Error('受管 profile 配置不能包含符号链接')
          return true
        } })
      } else {
        await writeFile(join(paths.stage, 'cordis.patch.yml'), '[]\n', { mode: 0o600 })
        await writeFile(join(paths.stage, 'pnpm-workspace.yaml'), `autoInstallPeers: false\nallowBuilds: {}\nstoreDir: ${JSON.stringify(join(paths.home, 'product-pnpm-store'))}\n`, { mode: 0o600 })
      }
      await atomicJson(join(paths.stage, 'package.json'), next)
      await install(paths.stage)
      await atomicJson(paths.journal, { ...state, phase: 'moving' })
      if (old) await rename(profile, paths.previous)
      await rename(paths.stage, profile)
      await atomicJson(paths.journal, { ...state, phase: 'installed' })
      if (!deferCommit) await recoverTransaction(paths, { healthy: true })
      return true
    } catch (error) {
      await recoverTransaction(paths)
      throw error
    }
  })
}
