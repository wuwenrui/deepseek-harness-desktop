/** Seed installation runs before the product profile is loaded. */
export function productSeedDependencies(seedDirectory: string, cache: string): Promise<Record<string, string>>
export function installProductSeeds(options: { profile: string; seedDirectory: string; install: (stage: string) => Promise<unknown>; productBundles?: readonly string[]; deferCommit?: boolean }): Promise<boolean>
export function prepareProductSeedsBoot(profile: string): Promise<boolean>
export function finalizeProductSeeds(profile: string): Promise<boolean>
export function rollbackProductSeeds(profile: string): Promise<boolean>
