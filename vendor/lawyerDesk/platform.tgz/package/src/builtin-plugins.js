/** Reviewed default plugin identities; shared by Web setup and the desktop seed loader. */
export const BUILTIN_PLUGINS = Object.freeze([
  Object.freeze({ packageName: '@changfenhuang/dsh-genui', version: '0.10.0-lawyer.1', archive: 'genui.tgz', upstream: 'https://github.com/omdsh-dev/dsh-genui', fork: 'https://github.com/wuwenrui/dsh-genui', baseCommit: '21ee4f42adc80452ade39fff07d40d646331caa1' }),
  Object.freeze({ packageName: 'dsh-better-sidebar', version: '0.19.1-lawyer.1', archive: 'materials.tgz', upstream: 'https://github.com/omdsh-dev/DSH-better-sidebar', fork: 'https://github.com/wuwenrui/DSH-better-sidebar', baseCommit: '1fcf43ccbedd6e66370b7fb81df2b4dd0ef2604e' }),
])

export const PRODUCT_BUNDLES = Object.freeze([
  '@deepseek-ai/dsh-base', '@deepseek-ai/dsh-web-app',
  '@deepseek-ai/dsh-experimental-agent-team-profile', '@deepseek-ai/dsh-experimental-agent-team-web-profile',
  '@lawyer-dsh/lawyer-platform', '@lawyer-dsh/lawyer-brand',
  ...BUILTIN_PLUGINS.map(plugin => plugin.packageName), '@lawyer-dsh/market',
])

// The source CLI Web distribution does not ship the desktop's experimental Team Web bundle.
export const WEB_PRODUCT_BUNDLES = Object.freeze(PRODUCT_BUNDLES.filter(name => !name.startsWith('@deepseek-ai/dsh-experimental-agent-team-')))

export const PRODUCT_SEEDS = Object.freeze([
  { packageName: '@lawyer-dsh/lawyer-platform', archive: 'platform.tgz' },
  { packageName: '@lawyer-dsh/lawyer-brand', archive: 'brand.tgz' },
  { packageName: '@lawyer-dsh/market', archive: 'market.tgz' },
  ...BUILTIN_PLUGINS,
])

export const PROTECTED_PACKAGES = Object.freeze(PRODUCT_SEEDS.map(seed => seed.packageName))

/** Replace only the product prefix, preserving market-added bundles in their existing order. */
export function composeProductBundles(bundles, productBundles = PRODUCT_BUNDLES) {
  if (!Array.isArray(bundles) || bundles.some(bundle => typeof bundle !== 'string')) throw new Error('无效的受管产品配置')
  const product = new Set(productBundles)
  return [...productBundles, ...bundles.filter(bundle => !product.has(bundle))]
}
