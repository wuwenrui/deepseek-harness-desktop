/** Product-owned services. No endpoint, catalog source or signing key comes from user config. */
import { readFileSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { createRequire } from 'node:module'
import { resolveDshHome } from '@deepseek-ai/dsh-home-paths'
import { LAWYER_PROVIDER, LAWYER_MODEL_URL, LAWYER_CREDENTIAL, isLawyerPolicyEnabled } from '@deepseek-ai/dsh-product-policy'

import { PROTECTED_PACKAGES } from './builtin-plugins.js'

const require = createRequire(import.meta.url)
const trust = Object.freeze(JSON.parse(readFileSync(new URL('../trust.json', import.meta.url), 'utf8')))
export const name = 'lawyer-platform'
export const inject = ['llm', 'settings', 'credentials', 'agentDefaultModel', 'agents', 'webServer', 'loader', 'tools']

/** 界面提交的模型能力上限（防超长/超量输入）。 */
const MAX_MODEL_SPECS = 200
const MAX_MODEL_ID = 128
/** 上下文窗口上限（token）：只用于挡住误输入，见 modelSpecs 里的说明。 */
const MAX_CONTEXT_WINDOW = 10_000_000

/**
 * 校验界面提交的模型能力清单（纯函数，便于单测）。
 * 只表达「哪些模型可选 + 每个模型收不收图片 + 上下文窗口」；协议、基址、凭据一律不出现在这里。
 * @param {unknown} value
 * @returns {Array<{id: string, name: string, vision: boolean, contextWindow?: number}>}
 */
export function modelSpecs(value) {
  if (!Array.isArray(value) || value.length === 0) throw new Error('至少要保留一个模型')
  if (value.length > MAX_MODEL_SPECS) throw new Error(`模型数量超过上限（${MAX_MODEL_SPECS}）`)
  const specs = []
  const seen = new Set()
  for (const item of value) {
    if (item === null || typeof item !== 'object' || Array.isArray(item)) throw new Error('模型条目格式无效')
    const id = item.id
    if (typeof id !== 'string' || id.trim() === '' || id.length > MAX_MODEL_ID) throw new Error('模型 id 无效')
    if (seen.has(id)) throw new Error(`模型「${id}」重复`)
    seen.add(id)
    const name = typeof item.name === 'string' && item.name.trim() !== '' ? item.name.slice(0, 128) : id
    if (item.vision !== undefined && typeof item.vision !== 'boolean') throw new Error(`模型「${id}」的图片能力必须是布尔值`)
    const contextWindow = item.contextWindow
    // 上限只挡「多打几个零」的误操作：任何真实模型都远小于 1e7 token，
    // 而内核会把填进来的值当硬容量用于溢出判定，写进去就没有第二道拦截。
    if (contextWindow !== undefined && (!Number.isSafeInteger(contextWindow) || contextWindow <= 0 || contextWindow > MAX_CONTEXT_WINDOW)) throw new Error(`模型「${id}」的上下文窗口无效`)
    specs.push({ id, name, vision: item.vision === true, ...(contextWindow === undefined ? {} : { contextWindow }) })
  }
  return specs
}

export function apply(ctx) {
  if (!isLawyerPolicyEnabled()) throw new Error('法律产品必须通过受管 lawyer profile 启动')
  const home = resolveDshHome()
  const desktop = ctx.get('lawyerDesktopRuntime')
  const profileDirectory = desktop?.profileDirectory ?? join(home, 'profiles', 'lawyer')
  const moduleFile = process.argv[1]
  if (!moduleFile && desktop === undefined) throw new Error('无法确定受管产品启动程序')
  let mutating = false
  ctx.on('agent/pre-step', (_request, next) => mutating ? Promise.resolve({ kind: 'reject' }) : next())

  /**
   * 读回当前**用户层**的模型行（含未暴露给界面的字段）。
   *
   * 为什么读 describe().user 而不是 get()：get() 返回的是 schema 解析后的值，
   * 省略的字段会被填成默认（例如 input 会变成 []），拿它回写会把「没表态」
   * 写成「明确声明不支持图片」。用户层才是用户的真实表态。
   * 写路径走设置服务（update）而不是直接改 settings.yaml：受管策略把文件写入锁死，
   * 只有这条带 schema 校验与冲突检测的通道是被允许的。
   */
  function internalModelSpecs() {
    const descriptor = ctx.settings.describe().find(item => item.ns === 'llm-pi-ai')
    const rows = descriptor?.user?.providers?.[LAWYER_PROVIDER]?.models
    if (!Array.isArray(rows)) return []
    return rows
      .filter(row => row !== null && typeof row === 'object' && typeof row.id === 'string')
      // 能力只认落盘的那一份声明：input 里有没有 image。写回时按它还原，
      // 不再另存 vision 字段——内核只读 input，两份数据共存迟早漂移。
      .map(row => ({
        id: row.id,
        name: row.name,
        vision: Array.isArray(row.input) && row.input.includes('image'),
        // 容量也要原样读回：界面每次保存提交的是整份清单，读不回就等于
        // 「保存一次模型能力，顺手把上下文窗口抹掉」。
        ...(Number.isSafeInteger(row.contextWindow) && row.contextWindow > 0 ? { contextWindow: row.contextWindow } : {}),
        ...(Number.isSafeInteger(row.maxTokens) && row.maxTokens > 0 ? { maxTokens: row.maxTokens } : {}),
      }))
  }

  /** 本站已开放的模型 id（来自当前生效的解析值：内置目录 ∪ 用户层）。 */
  async function openModelIds() {
    return new Set((await ctx.llm.listModels(LAWYER_PROVIDER)).map(model => model.id))
  }

  /** 把模型行写回用户设置：vision=true → input 含 image，否则只声明 text。 */
  async function writeModelSpecs(specs) {
    const models = specs.map(spec => ({
      id: spec.id,
      name: spec.name ?? spec.id,
      input: spec.vision === true ? ['text', 'image'] : ['text'],
      ...(spec.contextWindow === undefined ? {} : { contextWindow: spec.contextWindow }),
      ...(spec.maxTokens === undefined ? {} : { maxTokens: spec.maxTokens }),
    }))
    await ctx.settings.update('llm-pi-ai', { providers: { [LAWYER_PROVIDER]: { models } } })
  }

  const controller = {
    marketOptions() {
      return {
        catalogUrl: trust.catalogUrl,
        artifactOrigin: trust.artifactOrigin,
        publicKey: trust.publicKey,
        hostVersion: trust.hostVersion,
        profileDirectory,
        pnpm: desktop?.pnpm ?? { file: process.execPath, args: [join(dirname(require.resolve('pnpm')), require('pnpm').bin.pnpm)] },
        launcher: desktop?.launcher ?? { file: process.execPath, args: [...process.execArgv, moduleFile] },
        protectedPackages: [...PROTECTED_PACKAGES],
        beginMutation() {
          if (mutating || controller.marketOptions().agentsBusy()) throw new Error('请先结束当前任务')
          mutating = true
          return () => { mutating = false }
        },
        agentsBusy() {
          const agents = ctx.agents.list()
          if (!Array.isArray(agents)) return true
          return agents.some(agent => !['idle', 'error', 'disposed'].includes(agent.status))
        },
      }
    },
    async modelStatus() {
      const credential = await ctx.credentials.describe(LAWYER_CREDENTIAL)
      const declared = new Map((await internalModelSpecs()).map(spec => [spec.id, spec]))
      const models = []
      for (const listed of await ctx.llm.listModels(LAWYER_PROVIDER)) {
        // 「收不收图片」必须从运行时解析出来的模态读，不能从模型名猜：
        // 内核里 inputModalities 是 attachment 准入的唯一致命判据，
        // 和界面显示的不是同一份数据就会出现「界面说支持、一发就报不支持」。
        const info = await ctx.llm.resolveModelInfo(LAWYER_PROVIDER, listed.id)
        const own = declared.get(listed.id)
        models.push({
          id: listed.id,
          name: listed.name ?? listed.id,
          vision: info.inputModalities?.includes('image') === true,
          // contextWindow = 当前生效值（用户声明 ∪ 站点声明 ∪ 路由默认），
          // contextWindowOverride = 用户自己填的那一份。界面拿前者当占位提示、
          // 拿后者当输入框的值——两者混用会把「默认值」显示成「你设过」。
          ...(info.context?.contextWindow === undefined ? {} : { contextWindow: info.context.contextWindow }),
          ...(own?.contextWindow === undefined ? {} : { contextWindowOverride: own.contextWindow }),
        })
      }
      const selection = ctx.agentDefaultModel.currentSelection()
      return { site: 'https://model.codingrui.work', configured: credential.configured, writable: credential.writable, models, selected: selection.model }
    },
    async saveCredential(value) {
      if (typeof value !== 'string' || value.trim().length === 0 || value.length > 2048 || /\s/.test(value)) throw new Error('令牌格式无效')
      await ctx.credentials.set(LAWYER_CREDENTIAL, value)
    },
    async refreshModels() {
      // 合并而不是覆盖：刷新只更新「本站现在有哪些模型」，
      // 用户勾过的「这个模型收不收图片」必须保住——一次刷新就清空能力声明，
      // 等于把图片功能又关回去（这正是 2026-09-12 线上问题的形态）。
      const previous = new Map((await internalModelSpecs()).map(spec => [spec.id, spec]))
      const found = await ctx.llm.discoverModels('llm-pi-ai', { provider: LAWYER_PROVIDER, baseURL: LAWYER_MODEL_URL, api: 'openai-completions' })
      if (!Array.isArray(found) || found.length === 0) throw new Error('本站未返回此账号可用的模型')
      const models = found.map(model => {
        const own = previous.get(model.id)
        return {
          id: model.id,
          name: model.name ?? model.id,
          ...(own?.vision === true ? { vision: true } : {}),
          // 人工填过的容量优先于站点清单：刷新只负责更新「本站现在有哪些模型」，
          // 不该顺手把用户声明的容量改掉——和保住图片能力是同一条原则。
          ...(own?.contextWindow === undefined
            ? model.contextWindow === undefined ? {} : { contextWindow: model.contextWindow }
            : { contextWindow: own.contextWindow }),
          ...(own?.maxTokens === undefined
            ? model.maxTokens === undefined ? {} : { maxTokens: model.maxTokens }
            : { maxTokens: own.maxTokens }),
        }
      })
      await writeModelSpecs(models)
      const current = ctx.agentDefaultModel.currentSelection()
      if (!models.some(model => model.id === current.model)) await ctx.agentDefaultModel.saveSelection({ provider: LAWYER_PROVIDER, model: models[0].id })
      return controller.modelStatus()
    },
    /** 保存界面提交的模型能力清单（本站范围内，只改模型行，不碰路由/凭据/基址）。 */
    async saveModels(input) {
      const specs = modelSpecs(input)
      const open = await openModelIds()
      for (const spec of specs) {
        if (!open.has(spec.id)) throw new Error(`模型「${spec.id}」不在本站已开放的清单里，请先刷新可用模型`)
      }
      const selection = ctx.agentDefaultModel.currentSelection()
      if (specs.length > 0 && !specs.some(spec => spec.id === selection.model)) {
        throw new Error('默认模型不能被移除，请先把默认模型切到别的模型再删它')
      }
      await writeModelSpecs(specs)
      return controller.modelStatus()
    },
    async selectModel(id) {
      if (!(await ctx.llm.listModels(LAWYER_PROVIDER)).some(model => model.id === id)) throw new Error('只能选择本站已开放的模型')
      await ctx.agentDefaultModel.saveSelection({ provider: LAWYER_PROVIDER, model: id })
    },
  }
  ctx.provide('lawyerPlatform', Object.freeze(controller))
  let ready = false
  const appReady = ctx.get('appReady')
  if (!appReady) throw new Error('产品启动器未提供 readiness 服务')
  ctx.effect(() => appReady.onReady(() => { ready = true }))
  ctx.effect(() => ctx.webServer.register({ kind: 'exact', path: '/lawyer-platform/ready', handler(_request, response) {
    response.writeHead(ready ? 200 : 503, { 'content-type': 'application/json', 'cache-control': 'no-store' })
    response.end(JSON.stringify({ ready, product: 'lawyer', hostVersion: trust.hostVersion, tools: ctx.tools.schemas().map(tool => tool.name) }))
  } }))
}
