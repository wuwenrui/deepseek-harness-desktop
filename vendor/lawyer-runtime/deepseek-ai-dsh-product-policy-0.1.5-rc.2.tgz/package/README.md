---
description: "Process-owned model, launch and filesystem restrictions for the managed lawyer profile."
kind: "package-library"
---
# @deepseek-ai/dsh-product-policy

English | [中文](README.zh.md)

## Summary

The CLI activates this library before loading the `lawyer` profile. Activation is irreversible within the process; other upstream profiles retain their ordinary behavior. This is product governance, not isolation against malicious JavaScript running with the host's privileges.

## Use this package

The managed profile uses only `lawyercopilot` at `https://model.codingrui.work/v1`, through `openai-completions` and the `NEW_API_KEY` credential reference. The LLM registry checks registration, replacement, discovery and lookup. The pi-ai resolver validates resolved routes, and settings validates candidates before persistence or external-file publication. Requests to the model-site origin refuse redirects.

The launcher rejects managed-profile CLI plugin commands and patch overlays. Profile/home patches are rejected before plugin activation; configuration is startup-only and requires the platform and market entries. A process lease prevents concurrent product instances sharing one home.

The local filesystem executor checks canonical targets on resolution and reads/writes, including direct target calls. Product code, credentials, managed profiles and installation state are not case materials. Ordinary case folders remain usable. This check does not intercept trusted services' own Node filesystem operations.

The product roster includes all four shipped presets plus the default lawyer preset. Creation can define and inspect drafts; the dynamic runner rejects unreviewed Host/Client activation at both model and panel execution entry points. Selecting a different preset does not disable model-site or market policy.

## Model Experience

Indirectly, through the LLM and filesystem consumers that render policy rejections.

#### KV Cache effect

No direct changes to accepted request prefixes; consumer-owned policy errors may enter subsequent history.

## Known Limitations and Deferred Work

The policy protects the supported managed profile, not a machine administrator who modifies code or runs another program. Same-process plugins remain trusted code. The managed product's immutable startup combination and signed installer belong to its companion platform/market packages. This library provides no SaaS authorization or operating-system sandbox.

No runtime invariant companion is exported: this library owns no independently evolving session state; its consumers execute the policy at the protected operations. Focused runtime tests and the paired product's real-composition browser test cover enforcement.
