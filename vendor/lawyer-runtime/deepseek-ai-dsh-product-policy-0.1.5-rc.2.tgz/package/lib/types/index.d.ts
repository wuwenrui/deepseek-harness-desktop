/** The supported managed product profile. */
export declare const LAWYER_PROFILE = "lawyer";
/** The sole provider route available in the managed product. */
export declare const LAWYER_PROVIDER = "lawyercopilot";
/** Public model gateway, never a credential. */
export declare const LAWYER_MODEL_URL = "https://model.codingrui.work/v1";
/** Reference resolved by the credential service; no key is shipped. */
export declare const LAWYER_CREDENTIAL = "NEW_API_KEY";
/** Activate irreversible process-local policy before plugins load. */
export declare function enableLawyerPolicy(): void;
/** Whether this process was launched as the managed product. @returns The activation flag. */
export declare function isLawyerPolicyEnabled(): boolean;
/** A rejected product configuration or operation. */
export declare class ProductPolicyError extends Error {
    readonly code = "LAWYER_PRODUCT_POLICY";
    constructor(message: string);
}
/** Enforce the sole provider on registration, lookup and dispatch. @param provider - Resolved route name. */
export declare function assertLawyerProvider(provider: string): void;
/** Enforce an exact gateway URL rather than a hostname substring. @param value - Candidate API root. */
export declare function assertLawyerModelUrl(value: unknown): void;
/** Validate a resolved adapter profile before it can send a request. @param provider - Route name. @param value - Route fields. */
export declare function assertLawyerProviderConfig(provider: string, value: unknown): void;
/**
 * Check an entire settings candidate before schema defaults can discard
 * unknown fields.
 * @param ns - Namespace.
 * @param value - Merged candidate.
 */
export declare function assertLawyerSettings(ns: string, value: unknown): void;
/** Reject arbitrary endpoint probing through model discovery. @param ns - Adapter namespace. @param request - Discovery fields. */
export declare function assertLawyerDiscovery(ns: string, request: {
    provider?: string;
    baseURL?: string;
    api?: string;
}): void;
/**
 * Validate the startup-only composition, before any third-party entry executes.
 * @param rows - Final root rows.
 * @param allowedPackages - Installed, product-approved package names.
 */
export declare function assertLawyerComposition(rows: readonly unknown[], allowedPackages: readonly string[]): void;
/** Prevent model credentials following redirects, including SDK-owned fetch calls. @returns The installed fetch function. */
export declare function installLawyerFetchPolicy(): typeof globalThis.fetch;
/**
 * Own the managed home for this process; stale dead-process leases are
 * recoverable.
 * @param home - Resolved product home.
 * @returns Idempotent release for shutdown and isolated tests.
 */
export declare function claimLawyerProcess(home: string): () => void;
/**
 * Protect product code, credentials and installer state from model filesystem
 * capabilities.
 * @param home - Product data home.
 * @param anchor - Launcher package manifest.
 */
export declare function protectLawyerFiles(home: string, anchor: string): void;
/** Check canonical paths at the local filesystem executor, not only in tool prompts. @param path - Local backend path. */
export declare function assertLawyerFileAccess(path: string): void;
/** Require published, reviewed bundles instead of evaluating ad-hoc Host or Client plugin code. */
export declare function assertLawyerDynamicActivation(): void;
//# sourceMappingURL=index.d.ts.map