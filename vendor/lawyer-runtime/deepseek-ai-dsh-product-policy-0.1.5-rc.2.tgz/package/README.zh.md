---
description: "受管律师 profile 的进程级模型、启动和文件系统限制。"
kind: "package-library"
---
# @deepseek-ai/dsh-product-policy

[English](README.md) | 中文

## Summary

CLI 在装载 `lawyer` profile 前启用本库。启用后当前进程不可关闭策略；其他上游 profile 保留原有行为。这是产品治理，不是对具有宿主权限的恶意 JavaScript 的安全隔离。

## Use this package

受管 profile 只允许 `lawyercopilot` 通过 `openai-completions`、凭据引用 `NEW_API_KEY` 访问 `https://model.codingrui.work/v1`。LLM 注册表检查注册、替换、发现和查找；pi-ai 解析器校验最终路由；设置服务在持久化或发布外部文件变化前校验候选值。模型站请求拒绝重定向。

启动器拒绝受管 profile 的 CLI 插件命令及 patch 覆盖。在插件激活前拒绝 profile/home 用户补丁，要求 startup-only 组合，并确认平台和市场条目存在。进程租约防止多个产品实例共用同一 home。

本地文件系统执行器在解析及读取、写入时检查规范路径，包括直接传入 target 的调用。产品程序、凭据、受管 profile 和安装状态不是可操作的案件材料，普通案件目录仍可读写。此检查不拦截可信服务自己的 Node 文件操作。

产品目录包含上游四种预设和默认律师预设。创造模式可定义、检查草稿；动态 runner 在模型和面板两个执行入口拒绝未经审核的 Host/Client 激活。选择其他预设不会关闭模型站或市场策略。

## Model Experience

间接通过渲染策略拒绝结果的 LLM 和文件系统消费者影响模型。

#### KV Cache effect

不直接改变许可请求的前缀；由消费者持有的策略错误可能进入后续历史。

## Known Limitations and Deferred Work

策略保护受支持的受管 profile，不防御修改源码或另行运行程序的机器管理员。同进程插件仍须受信任。固定组合和签名安装由配套平台、市场包持有，本库不提供 SaaS 鉴权或操作系统沙箱。

不导出运行时 invariant：本库不拥有独立演进的会话状态，调用方在受保护操作处执行校验。定向服务测试与配套产品的真实组合浏览器测试验证这些限制。
