/**
 * Route paths, wire payloads, and the in-process launcher seam shared by the
 * host routes and their consumers, published as the `./shared` subpath.
 * Browser-safe: constants and types only.
 */
/** GET route serving the probed application ids. */
export declare const OPEN_IN_APP_APPS_ROUTE = "/open-in-app/apps";
/** GET prefix serving one PNG bundle icon per application id. */
export declare const OPEN_IN_APP_ICON_PREFIX = "/open-in-app/icon";
/** POST route launching one application on one workspace directory. */
export declare const OPEN_IN_APP_OPEN_ROUTE = "/open-in-app/open";
/** Apps-route response: catalog ids probed as installed, in menu order. */
export interface OpenInAppAppsPayload {
    readonly apps: readonly string[];
}
/** Open-route request body. */
export interface OpenInAppOpenPayload {
    readonly app: string;
    readonly path: string;
}
/**
 * Host-side seam for launching one installed catalog application on an
 * existing path. The plugin provides it as the optional `openInApp` service,
 * so an in-process Host caller reaches the same verified launchers the
 * browser routes use without a second catalog or a second resolution.
 */
export interface OpenInAppService {
    /**
     * Catalog ids this host resolved as installed, in menu order.
     * @returns installed application ids.
     */
    apps(): Promise<readonly string[]>;
    /**
     * Launch one installed application on one existing path.
     * @param appId - catalog id reported by {@link OpenInAppService.apps}.
     * @param path - absolute path to an existing file or directory.
     * @returns true once the application launched; false for an unknown id, an
     *   application this host cannot resolve, or a failed launch.
     */
    launch(appId: string, path: string): Promise<boolean>;
}
//# sourceMappingURL=shared.d.ts.map