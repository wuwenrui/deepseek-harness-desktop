import { type CatalogTrust, type ManagedCatalog } from './catalog.ts';
import { type Command } from './process.ts';
export interface ManagedMarketOptions extends CatalogTrust {
    profileDirectory: string;
    pnpm: Command;
    launcher: Command;
    protectedPackages: readonly string[];
    agentsBusy(): boolean;
    beginMutation?(): () => void;
}
interface Installed {
    id: string;
    packageName: string;
    version: string;
    sha256: string;
    source?: string;
    installedAt: string;
}
export declare class ManagedMarket {
    readonly root: string;
    private active;
    private pendingRestart;
    private stage;
    private readonly options;
    constructor(options: ManagedMarketOptions);
    status(): {
        managed: boolean;
        busy: boolean;
        stage: string;
        restartRequired: boolean;
        hostVersion: string;
    };
    /** Every read contacts the single central source; nothing is authorized from a local allowlist. */
    catalog(signal?: AbortSignal): Promise<ManagedCatalog>;
    installed(): Promise<Installed[]>;
    private approved;
    install(id: string, version: string, signal?: AbortSignal): Promise<{
        ok: true;
        restartRequired: true;
    }>;
    uninstall(id: string, signal?: AbortSignal): Promise<{
        ok: true;
        restartRequired: true;
    }>;
    private mutate;
    private transaction;
    private healthcheck;
}
/** Recover interrupted directory switches before launching the managed profile. */
export declare function recoverManagedProfile(profileDirectory: string): Promise<void>;
export {};
