export interface Command {
    file: string;
    args: string[];
    nodeMode?: boolean;
}
export declare function safeEnvironment(extra?: NodeJS.ProcessEnv): NodeJS.ProcessEnv;
export interface OwnedChild {
    done: Promise<void>;
    stop(): Promise<void>;
}
export declare function startOwned(command: Command, cwd: string, env: NodeJS.ProcessEnv, timeoutMs: number, signal?: AbortSignal): OwnedChild;
export declare function runOwned(command: Command, cwd: string, env: NodeJS.ProcessEnv, signal?: AbortSignal): Promise<void>;
