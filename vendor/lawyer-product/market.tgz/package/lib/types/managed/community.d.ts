/** One product-approved community plugin, pinned to the exact version we opened. */
export interface CommunityAllowlistEntry {
    /** Stable product identity shown to users and used by install requests. */
    id: string;
    /** GitHub owner of the reviewed repository. */
    owner: string;
    /** Reviewed repository URL; the community catalog entry must match it. */
    repo: string;
    /** Exact npm package name. */
    packageName: string;
    /** Exact version this product has approved. */
    version: string;
    /** Product category label shown in our market. */
    category: string;
    /** Whether this entry is currently open. Absent or false keeps it closed. */
    enabled: boolean;
    /** Pinned prebuilt archive; required when the catalog lists no npm package. */
    tarball?: {
        url: string;
        sha256: string;
        size: number;
    };
}
/** The operator-maintained source list that becomes the catalog's `community` array. */
export interface CommunityAllowlist {
    schemaVersion: 1;
    source: string;
    updatedAt: string;
    plugins: CommunityAllowlistEntry[];
}
/** One resolved entry exactly as it is signed into the product catalog. */
export interface CommunityCatalogEntry {
    id: string;
    owner: string;
    repo: string;
    packageName: string;
    version: string;
    name: string;
    description: string;
    category: string;
    hostVersions: string[];
    install: {
        kind: 'npm' | 'tarball';
        target: string;
        sha256?: string;
        size?: number;
    };
}
/** Parse and validate the operator source list. A closed or empty list is valid. */
export declare function parseCommunityAllowlist(value: unknown): CommunityAllowlist;
/**
 * Resolve the open list against the live community catalog at publish time.
 * The community list supplies metadata; this product supplies identity, the
 * exact version and the compatibility decision that get signed into our catalog.
 */
export declare function resolveCommunityCatalogEntries(allowlist: CommunityAllowlist, hostVersion: string, signal?: AbortSignal): Promise<CommunityCatalogEntry[]>;
/**
 * Fetch a pinned community archive. Redirects are allowed because the digest
 * from our signed catalog, not the URL, is what authorizes the bytes.
 */
export declare function downloadCommunityArtifact(packageName: string, install: {
    kind: 'npm' | 'tarball';
    target: string;
    sha256?: string;
    size?: number;
} | undefined, cache: string, signal?: AbortSignal): Promise<string>;
