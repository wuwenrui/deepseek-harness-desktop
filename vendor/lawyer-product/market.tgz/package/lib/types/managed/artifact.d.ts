import { type ManagedRelease } from './catalog.ts';
export declare function assertBundleManifest(value: unknown, release: ManagedRelease): Record<string, unknown>;
export declare function assertBundlePatch(value: unknown, packageName: string): void;
/**
 * Validate a community bundle's composition patch. Community plugins may add
 * their own rows and their own dependencies; they may not replace a product
 * row, mount another package, or create a group.
 */
export declare function assertCommunityBundlePatch(value: unknown, packageName: string): void;
/** Verify an installed community package: exact identity plus an insert-only composition. */
export declare function verifyCommunityPackage(root: string, release: ManagedRelease): Promise<void>;
export declare function verifyArtifact(file: string, release: ManagedRelease): Promise<void>;
export declare function downloadArtifact(release: ManagedRelease, cache: string, signal?: AbortSignal): Promise<string>;
