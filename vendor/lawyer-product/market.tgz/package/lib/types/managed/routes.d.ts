import type { MarketHost } from '../routes.ts';
import { type ManagedMarketOptions } from './engine.ts';
export interface LawyerPlatform {
    marketOptions(): ManagedMarketOptions;
    modelStatus(): Promise<unknown>;
    saveCredential(value: string): Promise<void>;
    refreshModels(): Promise<unknown>;
    selectModel(id: string): Promise<void>;
}
export declare function mountManagedMarket(host: MarketHost, platform: LawyerPlatform): () => Promise<void>;
