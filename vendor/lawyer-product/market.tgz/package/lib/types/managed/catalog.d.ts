import type { ManagedCatalog, CatalogTrust } from './types.ts';
export type { ManagedRelease, ManagedCatalog, CatalogTrust } from './types.ts';
export declare class ManagedError extends Error {
    readonly code: string;
    readonly status: number;
    constructor(code: string, message: string, status?: number);
}
export declare const MAX_CATALOG_BYTES: number;
export declare const MAX_ARTIFACT_BYTES: number;
export declare function object(value: unknown): Record<string, unknown>;
export declare function decodeCatalog(bytes: Uint8Array, trust: CatalogTrust, minimumRevision?: number, now?: number): ManagedCatalog;
/** Read bounded bytes without following redirects or inheriting model credentials. */
export declare function fetchBytes(url: string, max: number, signal?: AbortSignal): Promise<Buffer>;
