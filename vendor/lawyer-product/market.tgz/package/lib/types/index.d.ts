/** Managed lawyer-market entry. The unrestricted community routes are not mounted. */
import type { Context } from '@deepseek-ai/cordis';
import { type LawyerPlatform } from './managed/routes.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        lawyerPlatform: LawyerPlatform;
    }
}
export declare const name = "lawyer-market";
export declare const inject: string[];
/** Mount only the managed operations after the product controller is available. */
export declare function apply(ctx: Context, config?: Record<string, never>): void;
