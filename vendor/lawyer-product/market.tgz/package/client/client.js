window.__ModuleLoader__.load({ id: "@lawyer-dsh/market", factory: (require) => {


		var module = { exports: {} };
		var exports = module.exports;
		Object.defineProperty(exports, Symbol.toStringTag, { value: "Module" });
		let react = require("react");
		let react_jsx_runtime = require("react/jsx-runtime");
		//#region src/client/market-data.ts
		/** One registry entry from /dsh-market/registry. */
		/**
		* Resolve a market API path against the page the UI is served from.
		*
		* Every call used to be root-absolute (`/dsh-market/…`), which the browser
		* resolves against the ORIGIN — so behind a reverse proxy that mounts dsh
		* under a prefix (`https://host/app/my-dsh/`), the panel rendered and then
		* every request in it went to `https://host/dsh-market/…`, missed the prefix
		* rule entirely, and 404'd (#345).
		*
		* Anchored on `document.baseURI`, which is the directory the host serves its
		* UI from. Safe for root deployments because that directory is `/` there, and
		* safe generally because the dsh web UI does not use path routing — measured
		* against a real dsh: `location.pathname` is `/` on the market page, not
		* `/settings/...`, so the directory really is the mount point rather than
		* wherever the user happens to have navigated.
		*/
		function api(path) {
			const relative = path.replace(/^\/+/, "");
			if (typeof document === "undefined") return `/${relative}`;
			return new URL(relative, document.baseURI).pathname;
		}
		//#endregion
		//#region \0dsh-css:src/client/ManagedMarket.module.css.mjs
		const css = "._1FIEtG_root{color:inherit;width:100%;max-width:1040px;padding:16px 8px;line-height:1.65}._1FIEtG_header{justify-content:space-between;align-items:flex-start;gap:20px;display:flex}._1FIEtG_header p{max-width:680px}._1FIEtG_grid{grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px;display:grid}._1FIEtG_card{border:1px solid color-mix(in srgb, currentColor 18%, transparent);background:color-mix(in srgb, currentColor 3%, transparent);border-radius:12px;padding:20px}._1FIEtG_card h4{margin:8px 0;font-size:17px}._1FIEtG_category,._1FIEtG_muted{opacity:.65;font-size:12px}._1FIEtG_root button{color:inherit;border:1px solid color-mix(in srgb, currentColor 25%, transparent);background:color-mix(in srgb, currentColor 6%, transparent);cursor:pointer;border-radius:7px;margin:5px 0;padding:7px 14px}._1FIEtG_root button:disabled{opacity:.45;cursor:not-allowed}._1FIEtG_root button:hover:not(:disabled){background:color-mix(in srgb, currentColor 13%, transparent)}._1FIEtG_root form{flex-wrap:wrap;align-items:end;gap:12px;margin:18px 0;display:flex}._1FIEtG_root label{gap:6px;min-width:260px;display:grid}._1FIEtG_root input,._1FIEtG_root select{color:inherit;border:1px solid color-mix(in srgb, currentColor 25%, transparent);background:0 0;border-radius:6px;min-width:260px;padding:9px}._1FIEtG_root option{color:#18202c;background:#fff}._1FIEtG_notice,._1FIEtG_error{border:1px solid;border-radius:8px;padding:12px 16px}._1FIEtG_notice{color:#168063;background:#16806314}._1FIEtG_error{color:#ba4343;background:#ba434314}._1FIEtG_root a{color:inherit;text-decoration:underline}@media (max-width:560px){._1FIEtG_header{flex-direction:column}._1FIEtG_grid{grid-template-columns:1fr}._1FIEtG_root label,._1FIEtG_root input,._1FIEtG_root select{width:100%;min-width:0}}";
		const tagId = "@lawyer-dsh/market/ManagedMarket.module.css";
		if (typeof document !== "undefined" && document.querySelector("style[data-plugin-css=" + JSON.stringify(tagId) + "]") === null) {
			const tag = document.createElement("style");
			tag.dataset.plugin = "@lawyer-dsh/market";
			tag.dataset.pluginCss = tagId;
			tag.textContent = css;
			document.head.appendChild(tag);
		}
		var ManagedMarket_module_css_default = {
			"card": "_1FIEtG_card",
			"category": "_1FIEtG_category",
			"error": "_1FIEtG_error",
			"grid": "_1FIEtG_grid",
			"header": "_1FIEtG_header",
			"muted": "_1FIEtG_muted",
			"notice": "_1FIEtG_notice",
			"root": "_1FIEtG_root"
		};
		//#endregion
		//#region src/client/ManagedMarket.tsx
		const managedZh = {
			market: "律师能力",
			models: "模型服务",
			loading: "正在加载…",
			retry: "刷新目录",
			empty: "平台尚未开放可安装的能力",
			installed: "已安装",
			available: "可安装能力",
			install: "安装",
			update: "更新",
			remove: "卸载",
			incompatible: "暂不兼容当前版本",
			managed: "仅显示平台审核并允许安装的能力。插件来源与版本由平台统一管理。",
			confirm: "确认执行此插件操作？正在进行的办案任务需要先结束。",
			restart: "变更已通过启动检查。请关闭并重新启动工作台后使用新能力；重启前不能继续修改插件。",
			failed: "操作未完成",
			revision: "目录版本",
			fixed: "模型服务由平台统一提供，不支持添加其他模型站。",
			account: "账户与充值",
			key: "本站 API 令牌",
			save: "保存令牌",
			saved: "令牌已保存，可刷新可用模型。",
			refresh: "刷新可用模型",
			select: "默认模型",
			choose: "保存默认模型",
			configured: "已配置本站令牌",
			missing: "尚未配置本站令牌",
			readonly: "令牌由启动环境提供，请在启动环境中更新。",
			savedModel: "默认模型已更新，新对话生效。",
			progress: "正在校验并准备插件环境，请稍候…",
			selected: "当前默认模型",
			errorTitle: "暂时无法读取平台目录",
			noFallback: "不会切换到公共社区目录，请稍后重试。",
			site: "我们的模型站",
			current: "当前版本",
			none: "暂无模型，请先配置本站令牌并刷新。",
			pending: "等待重启",
			checking: "正在检查新环境",
			authorizing: "正在核验平台许可",
			preparing: "正在安装到隔离环境",
			idle: "就绪",
			savedOk: "保存成功",
			owned: "平台审核",
			community: "社区"
		};
		const managedEn = {
			market: "Legal capabilities",
			models: "Model service",
			loading: "Loading…",
			retry: "Refresh catalog",
			empty: "No capabilities are currently approved",
			installed: "Installed",
			available: "Available capabilities",
			install: "Install",
			update: "Update",
			remove: "Uninstall",
			incompatible: "Not compatible with this version",
			managed: "Only centrally reviewed and approved capabilities are listed. The platform manages sources and versions.",
			confirm: "Confirm this plugin operation? Finish active tasks first.",
			restart: "The new environment passed its startup check. Close and restart the workbench to use the changes. Further plugin changes are blocked until restart.",
			failed: "Operation did not complete",
			revision: "Catalog revision",
			fixed: "This product uses our model service only. Other model endpoints cannot be added.",
			account: "Account and billing",
			key: "Platform API token",
			save: "Save token",
			saved: "Token saved. Refresh available models.",
			refresh: "Refresh models",
			select: "Default model",
			choose: "Save default",
			configured: "Platform token configured",
			missing: "Platform token not configured",
			readonly: "The launching environment owns this credential. Update it there.",
			savedModel: "Default saved for new conversations.",
			progress: "Validating and preparing the plugin environment…",
			selected: "Current default",
			errorTitle: "Platform catalog unavailable",
			noFallback: "No public community fallback is used. Retry later.",
			site: "Our model service",
			current: "Current version",
			none: "No models. Configure your platform token and refresh.",
			pending: "Restart required",
			checking: "Checking the new environment",
			authorizing: "Checking platform approval",
			preparing: "Preparing an isolated environment",
			idle: "Ready",
			savedOk: "Saved",
			owned: "Reviewed",
			community: "Community"
		};
		async function request(path, body) {
			const response = await fetch(api(`dsh-market/${path}`), {
				method: body === void 0 ? "GET" : "POST",
				credentials: "same-origin",
				headers: {
					"content-type": "application/json",
					"x-lawyer-market": "1"
				},
				...body === void 0 ? {} : { body: JSON.stringify(body) }
			});
			const value = await response.json();
			if (!response.ok) throw new Error(value.error ?? "Request failed");
			return value;
		}
		function ManagedMarketSection({ t }) {
			const [catalog, setCatalog] = (0, react.useState)(null), [installed, setInstalled] = (0, react.useState)([]);
			const [status, setStatus] = (0, react.useState)({
				busy: false,
				stage: "idle",
				restartRequired: false
			});
			const [error, setError] = (0, react.useState)(""), [operationError, setOperationError] = (0, react.useState)(""), [busy, setBusy] = (0, react.useState)(false);
			const load = async () => {
				setError("");
				const current = await request("installed");
				setInstalled(current.installed);
				setStatus(current);
				try {
					setCatalog(await request("registry"));
				} catch (e) {
					setCatalog(null);
					setError(String(e instanceof Error ? e.message : e));
				}
			};
			(0, react.useEffect)(() => {
				load().catch((e) => setError(String(e)));
			}, []);
			(0, react.useEffect)(() => {
				if (!busy) return;
				const timer = setInterval(() => {
					request("status").then(setStatus).catch(() => void 0);
				}, 700);
				return () => clearInterval(timer);
			}, [busy]);
			const perform = async (path, body) => {
				if (!window.confirm(t("confirm"))) return;
				setBusy(true);
				setOperationError("");
				try {
					await request(path, body);
					await load();
				} catch (e) {
					setOperationError(e instanceof Error ? e.message : String(e));
				} finally {
					setBusy(false);
				}
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
				className: ManagedMarket_module_css_default.root,
				"aria-label": t("market"),
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("header", {
						className: ManagedMarket_module_css_default.header,
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h2", { children: t("market") }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("managed") })] }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							onClick: () => void load().catch((e) => setError(String(e))),
							disabled: busy,
							children: t("retry")
						})]
					}),
					status.restartRequired && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						role: "status",
						className: ManagedMarket_module_css_default.notice,
						children: t("restart")
					}),
					busy && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						role: "status",
						className: ManagedMarket_module_css_default.notice,
						children: t(status.stage === "checking" ? "checking" : status.stage === "authorizing" ? "authorizing" : "preparing")
					}),
					operationError && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						role: "alert",
						className: ManagedMarket_module_css_default.error,
						children: operationError
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", { children: t("installed") }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: ManagedMarket_module_css_default.grid,
						children: installed.map((item) => /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("article", {
							className: ManagedMarket_module_css_default.card,
							children: [
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h4", { children: catalog?.plugins.find((p) => p.id === item.id)?.name ?? item.id }),
								/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", { children: [
									t("current"),
									" ",
									item.version
								] }),
								/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
									disabled: busy || status.restartRequired,
									onClick: () => void perform("uninstall", { id: item.id }),
									children: t("remove")
								})
							]
						}, item.id))
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h3", { children: t("available") }),
					error && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("div", {
						role: "alert",
						className: ManagedMarket_module_css_default.error,
						children: [
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: t("errorTitle") }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: error }),
							/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("noFallback") })
						]
					}),
					catalog === null && !error && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("loading") }),
					catalog?.plugins.length === 0 && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("empty") }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("div", {
						className: ManagedMarket_module_css_default.grid,
						children: catalog?.plugins.map((item) => {
							const current = installed.find((p) => p.id === item.id), same = current?.version === item.version;
							return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("article", {
								className: ManagedMarket_module_css_default.card,
								children: [
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: ManagedMarket_module_css_default.category,
										children: item.category
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("span", {
										className: ManagedMarket_module_css_default.source,
										children: t(item.source === "community" ? "community" : "owned")
									}),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h4", { children: item.name }),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: item.description }),
									/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", { children: ["v", item.version] }),
									/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
										disabled: busy || status.restartRequired || same || !item.compatible,
										onClick: () => void perform(current ? "update" : "install", {
											id: item.id,
											version: item.version
										}),
										children: !item.compatible ? t("incompatible") : same ? t("installed") : t(current ? "update" : "install")
									})
								]
							}, item.id);
						})
					}),
					catalog && /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", {
						className: ManagedMarket_module_css_default.muted,
						children: [
							t("revision"),
							" ",
							catalog.revision
						]
					})
				]
			});
		}
		function ManagedModelsSection({ t }) {
			const [data, setData] = (0, react.useState)(null), [key, setKey] = (0, react.useState)(""), [selected, setSelected] = (0, react.useState)("");
			const [message, setMessage] = (0, react.useState)(""), [error, setError] = (0, react.useState)(""), [busy, setBusy] = (0, react.useState)(false);
			const load = async () => {
				const data = await request("models");
				setData(data);
				setSelected(data.selected);
			};
			(0, react.useEffect)(() => {
				load().catch((e) => setError(String(e)));
			}, []);
			const action = async (path, body, message) => {
				setBusy(true);
				setError("");
				setMessage("");
				try {
					await request(path, body);
					setKey("");
					await load();
					setMessage(t(message));
				} catch (e) {
					setError(e instanceof Error ? e.message : String(e));
				} finally {
					setBusy(false);
				}
			};
			return /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("section", {
				className: ManagedMarket_module_css_default.root,
				"aria-label": t("models"),
				children: [
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("h2", { children: t("models") }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("fixed") }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("p", { children: [
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("strong", { children: t("site") }),
						" · ",
						/* @__PURE__ */ (0, react_jsx_runtime.jsx)("a", {
							href: "https://model.codingrui.work",
							target: "_blank",
							rel: "noopener noreferrer",
							children: t("account")
						})
					] }),
					error && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						role: "alert",
						className: ManagedMarket_module_css_default.error,
						children: error
					}),
					message && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", {
						role: "status",
						className: ManagedMarket_module_css_default.notice,
						children: message
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: data?.configured ? t("configured") : t("missing") }),
					data?.writable === false && /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("readonly") }),
					/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("form", {
						onSubmit: (event) => {
							event.preventDefault();
							action("credential", { key }, "saved");
						},
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("key"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("input", {
							type: "password",
							autoComplete: "new-password",
							value: key,
							onChange: (e) => setKey(e.target.value),
							disabled: busy || data?.writable === false
						})] }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							disabled: busy || key.trim().length === 0 || data?.writable === false,
							children: t("save")
						})]
					}),
					/* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
						disabled: busy || !data?.configured,
						onClick: () => void action("refresh-models", {}, "savedOk"),
						children: t("refresh")
					}),
					data && data.models.length > 0 ? /* @__PURE__ */ (0, react_jsx_runtime.jsxs)("form", {
						onSubmit: (event) => {
							event.preventDefault();
							action("select-model", { model: selected }, "savedModel");
						},
						children: [/* @__PURE__ */ (0, react_jsx_runtime.jsxs)("label", { children: [t("select"), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("select", {
							value: selected,
							onChange: (e) => setSelected(e.target.value),
							children: data.models.map((model) => /* @__PURE__ */ (0, react_jsx_runtime.jsx)("option", {
								value: model.id,
								children: model.name
							}, model.id))
						})] }), /* @__PURE__ */ (0, react_jsx_runtime.jsx)("button", {
							disabled: busy || selected === "",
							children: t("choose")
						})]
					}) : /* @__PURE__ */ (0, react_jsx_runtime.jsx)("p", { children: t("none") })
				]
			});
		}
		//#endregion
		//#region src/client/index.ts
		/**
		* dsh-market client: registers a "Market" settings section rendering the
		* plugin market UI, plus the post-install toast in the shell overlay layer.
		* Built by tsdown into the __ModuleLoader__ factory bundle at
		* client/client.js; the only externals are the loader module table's react
		* entries.
		*/
		/**
		* Primitives this bundle relies on that did not exist before rc.6. The
		* primitives module is host-injected (external at build time), so on an
		* older host the module resolves but these named exports are undefined —
		* rendering would throw and blank the whole settings dialog. Returning the
		* gaps lets apply() skip registration for a clean downgrade instead.
		*/
		const REQUIRED_PRIMITIVES = [
			"Menu",
			"DisclosureRow",
			"Tooltip",
			"Toast"
		];
		function missingPrimitives(mod, required = REQUIRED_PRIMITIVES) {
			return required.filter((name) => mod[name] === void 0);
		}
		const name = "lawyer-market";
		const inject = [
			"slots",
			"locale",
			"theme"
		];
		function apply(ctx) {
			ctx.effect(() => ctx.locale.register("lawyer-market", {
				zh: managedZh,
				en: managedEn
			}), "lawyer-market: locale");
			const t = ctx.locale.bind("lawyer-market");
			ctx.slots.inject("settings.section", () => {
				const a = ctx.slots.register({
					name: "settings.section",
					id: "models",
					order: 30,
					label: () => t("models"),
					locale: "lawyer-market",
					inject: () => ({ t })
				}, () => (0, react.createElement)(ManagedModelsSection, { t }));
				const b = ctx.slots.register({
					name: "settings.section",
					id: "lawyer-market",
					order: 40,
					label: () => t("market"),
					locale: "lawyer-market",
					inject: () => ({ t })
				}, () => (0, react.createElement)(ManagedMarketSection, { t }));
				return () => {
					if (typeof a === "function") a();
					if (typeof b === "function") b();
				};
			});
		}
		//#endregion
		exports.REQUIRED_PRIMITIVES = REQUIRED_PRIMITIVES;
		exports.apply = apply;
		exports.inject = inject;
		exports.missingPrimitives = missingPrimitives;
		exports.name = name;
		return module.exports;
	}
});
