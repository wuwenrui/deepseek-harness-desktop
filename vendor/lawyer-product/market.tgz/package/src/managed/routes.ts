/** Managed-only HTTP facade; legacy community mutation endpoints are not mounted. */
import type { IncomingMessage, ServerResponse } from 'node:http'
import { sameOrigin, readJsonBody, sendJson } from '../http.ts'
import type { MarketHost } from '../routes.ts'
import { ManagedMarket, type ManagedMarketOptions } from './engine.ts'
import { ManagedError, object } from './catalog.ts'

export interface LawyerPlatform {
  marketOptions(): ManagedMarketOptions
  modelStatus(): Promise<unknown>
  saveCredential(value: string): Promise<void>
  refreshModels(): Promise<unknown>
  selectModel(id: string): Promise<void>
}
function fields(value: unknown, allowed: string[]): Record<string, unknown> {
  const body = object(value)
  if (Object.keys(body).some(key => !allowed.includes(key))) throw new ManagedError('UNMANAGED_SETTING', '此设置由平台管理，不能修改', 403)
  return body
}
function text(value: unknown, max: number): string {
  if (typeof value !== 'string' || value.length === 0 || value.length > max) throw new ManagedError('INVALID_REQUEST', '请求参数无效')
  return value
}
/** The shipped product is local-only; same-origin alone does not stop DNS rebinding. */
function localRequest(request: IncomingMessage): boolean {
  if (!['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(request.socket.remoteAddress ?? '')) return false
  if (request.headers.forwarded !== undefined || request.headers['x-forwarded-for'] !== undefined || request.headers['x-forwarded-host'] !== undefined) return false
  const host = request.headers.host
  if (typeof host !== 'string' || host.length > 256) return false
  try {
    const url = new URL(`http://${host}`)
    if (!['127.0.0.1', 'localhost', '[::1]'].includes(url.hostname) || Number(url.port || '80') !== request.socket.localPort || url.username !== '' || url.password !== '') return false
  } catch { return false }
  return request.headers.origin === undefined || sameOrigin(request)
}
export function mountManagedMarket(host: MarketHost, platform: LawyerPlatform): () => Promise<void> {
  const market = new ManagedMarket(platform.marketOptions())
  const stop = new AbortController(), pending = new Set<Promise<void>>()
  const handler = async (request: IncomingMessage, response: ServerResponse): Promise<void> => {
    const url = new URL(request.url ?? '/', 'http://localhost'), path = url.pathname
    const abort = new AbortController()
    const disconnected = (): void => { if (!response.writableEnded) abort.abort() }
    response.once('close', disconnected)
    const signal = AbortSignal.any([abort.signal, stop.signal])
    try {
      if (!localRequest(request)) throw new ManagedError('UNTRUSTED_REQUEST', '仅允许本机工作台访问', 403)
      if (request.method === 'GET') {
        if (path === '/dsh-market/status') return sendJson(response, 200, market.status())
        if (path === '/dsh-market/installed') return sendJson(response, 200, { installed: await market.installed(), ...market.status() })
        if (path === '/dsh-market/registry') {
          const catalog = await market.catalog(signal)
          const hostVersion = platform.marketOptions().hostVersion
          return sendJson(response, 200, {
            revision: catalog.revision,
            expiresAt: catalog.expiresAt,
            plugins: catalog.plugins.map(({ artifact: _artifact, install: _install, ...plugin }) => ({
              ...plugin,
              compatible: plugin.hostVersions.includes(hostVersion),
            })),
          })
        }
        if (path === '/dsh-market/models') return sendJson(response, 200, await platform.modelStatus())
      }
      if (request.method !== 'POST' || !sameOrigin(request) || request.headers['x-lawyer-market'] !== '1') throw new ManagedError('UNTRUSTED_REQUEST', '不允许此操作来源', 403)
      switch (path) {
        case '/dsh-market/install':
        case '/dsh-market/update': {
          const body = fields(await readJsonBody(request), ['id', 'version'])
          const result = await market.install(text(body.id, 80), text(body.version, 80), signal)
          return sendJson(response, 200, result)
        }
        case '/dsh-market/uninstall': {
          const body = fields(await readJsonBody(request), ['id'])
          return sendJson(response, 200, await market.uninstall(text(body.id, 80), signal))
        }
        case '/dsh-market/credential': {
          const body = fields(await readJsonBody(request), ['key'])
          await platform.saveCredential(text(body.key, 2048))
          return sendJson(response, 200, { ok: true })
        }
        case '/dsh-market/refresh-models': {
          fields(await readJsonBody(request), [])
          return sendJson(response, 200, await platform.refreshModels())
        }
        case '/dsh-market/select-model': {
          const body = fields(await readJsonBody(request), ['model'])
          await platform.selectModel(text(body.model, 256))
          return sendJson(response, 200, { ok: true })
        }
        default: throw new ManagedError('MANAGED_ONLY', '产品只允许通过平台目录管理业务能力；此入口已关闭', 403)
      }
    } catch (error) {
      if (!response.destroyed && !response.headersSent) {
        const known = error instanceof ManagedError
        sendJson(response, known ? error.status : 400, { error: known ? error.message : '操作未完成，请检查配置或联系平台支持', code: known ? error.code : 'OPERATION_FAILED' })
      }
    } finally { response.off('close', disconnected) }
  }
  const dispose = host.webServer.register({ kind: 'prefix', path: '/dsh-market', handler(request, response) {
    const task = handler(request, response)
    pending.add(task)
    void task.finally(() => pending.delete(task)).catch(() => undefined)
    return task
  } })
  return async () => { dispose(); stop.abort(); await Promise.allSettled([...pending]) }
}
