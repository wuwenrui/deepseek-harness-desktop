/** Managed lawyer-market entry. The unrestricted community routes are not mounted. */
import type { Context } from '@deepseek-ai/cordis'
import { mountManagedMarket, type LawyerPlatform } from './managed/routes.ts'
import { ManagedError } from './managed/catalog.ts'
import type { MarketHost } from './routes.ts'

declare module '@deepseek-ai/cordis' { interface Context { lawyerPlatform: LawyerPlatform } }
export const name = 'lawyer-market'
export const inject = ['webServer', 'loader', 'lawyerPlatform']
/** Mount only the managed operations after the product controller is available. */
export function apply(ctx: Context, config?: Record<string, never>): void {
  if (config !== undefined && Object.keys(config).length > 0) throw new ManagedError('PRODUCT_OWNED', '市场配置由产品管理', 403)
  if (ctx.lawyerPlatform === undefined) throw new ManagedError('PLATFORM_REQUIRED', '此市场必须由受管法律产品装载', 403)
  ctx.effect(() => mountManagedMarket(ctx as unknown as MarketHost, ctx.lawyerPlatform), 'lawyer-market: managed routes')
}
