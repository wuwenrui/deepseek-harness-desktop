import { api } from './market-data.ts'
import { useEffect, useState } from 'react'
import type { ManagedRelease } from '../managed/types.ts'
import styles from './ManagedMarket.module.css'

export const managedZh = {
  market: '律师能力', models: '模型服务', loading: '正在加载…', retry: '刷新目录', empty: '平台尚未开放可安装的能力', installed: '已安装', available: '可安装能力', install: '安装', update: '更新', remove: '卸载', incompatible: '暂不兼容当前版本', managed: '仅显示平台审核并允许安装的能力。插件来源与版本由平台统一管理。', confirm: '确认执行此插件操作？正在进行的办案任务需要先结束。', restart: '变更已通过启动检查。请关闭并重新启动工作台后使用新能力；重启前不能继续修改插件。', failed: '操作未完成', revision: '目录版本', fixed: '模型服务由平台统一提供，不支持添加其他模型站。', account: '账户与充值', key: '本站 API 令牌', save: '保存令牌', saved: '令牌已保存，可刷新可用模型。', refresh: '刷新可用模型', select: '默认模型', choose: '保存默认模型', configured: '已配置本站令牌', missing: '尚未配置本站令牌', readonly: '令牌由启动环境提供，请在启动环境中更新。', savedModel: '默认模型已更新，新对话生效。', progress: '正在校验并准备插件环境，请稍候…', selected: '当前默认模型', errorTitle: '暂时无法读取平台目录', noFallback: '不会切换到公共社区目录，请稍后重试。', site: '我们的模型站', current: '当前版本', none: '暂无模型，请先配置本站令牌并刷新。', pending: '等待重启', checking: '正在检查新环境', authorizing: '正在核验平台许可', preparing: '正在安装到隔离环境', idle: '就绪', savedOk: '保存成功', owned: '平台审核', community: '社区', 
}
export const managedEn: Record<keyof typeof managedZh, string> = {
  market: 'Legal capabilities', models: 'Model service', loading: 'Loading…', retry: 'Refresh catalog', empty: 'No capabilities are currently approved', installed: 'Installed', available: 'Available capabilities', install: 'Install', update: 'Update', remove: 'Uninstall', incompatible: 'Not compatible with this version', managed: 'Only centrally reviewed and approved capabilities are listed. The platform manages sources and versions.', confirm: 'Confirm this plugin operation? Finish active tasks first.', restart: 'The new environment passed its startup check. Close and restart the workbench to use the changes. Further plugin changes are blocked until restart.', failed: 'Operation did not complete', revision: 'Catalog revision', fixed: 'This product uses our model service only. Other model endpoints cannot be added.', account: 'Account and billing', key: 'Platform API token', save: 'Save token', saved: 'Token saved. Refresh available models.', refresh: 'Refresh models', select: 'Default model', choose: 'Save default', configured: 'Platform token configured', missing: 'Platform token not configured', readonly: 'The launching environment owns this credential. Update it there.', savedModel: 'Default saved for new conversations.', progress: 'Validating and preparing the plugin environment…', selected: 'Current default', errorTitle: 'Platform catalog unavailable', noFallback: 'No public community fallback is used. Retry later.', site: 'Our model service', current: 'Current version', none: 'No models. Configure your platform token and refresh.', pending: 'Restart required', checking: 'Checking the new environment', authorizing: 'Checking platform approval', preparing: 'Preparing an isolated environment', idle: 'Ready', savedOk: 'Saved', owned: 'Reviewed', community: 'Community', 
}
export type ManagedTranslate = (key: keyof typeof managedZh) => string
interface Status { busy: boolean; stage: string; restartRequired: boolean }
interface Installed { id: string; packageName: string; version: string }
interface Catalog { revision: number; plugins: Array<Omit<ManagedRelease, 'artifact' | 'install'> & { compatible: boolean }> }
interface Models { site: string; configured: boolean; writable: boolean; models: Array<{ id: string; name: string }>; selected: string }
async function request<T>(path: string, body?: unknown): Promise<T> {
  const response = await fetch(api(`dsh-market/${path}`), { method: body === undefined ? 'GET' : 'POST', credentials: 'same-origin', headers: { 'content-type': 'application/json', 'x-lawyer-market': '1' }, ...(body === undefined ? {} : { body: JSON.stringify(body) }) })
  const value = await response.json() as T & { error?: string }
  if (!response.ok) throw new Error(value.error ?? 'Request failed')
  return value
}
export function ManagedMarketSection({ t }: { t: ManagedTranslate }) {
  const [catalog, setCatalog] = useState<Catalog | null>(null), [installed, setInstalled] = useState<Installed[]>([])
  const [status, setStatus] = useState<Status>({ busy: false, stage: 'idle', restartRequired: false })
  const [error, setError] = useState(''), [operationError, setOperationError] = useState(''), [busy, setBusy] = useState(false)
  const load = async () => {
    setError('')
    const current = await request<{ installed: Installed[] } & Status>('installed')
    setInstalled(current.installed); setStatus(current)
    try { setCatalog(await request<Catalog>('registry')) } catch (e) { setCatalog(null); setError(String(e instanceof Error ? e.message : e)) }
  }
  useEffect(() => { void load().catch(e => setError(String(e))) }, [])
  useEffect(() => {
    if (!busy) return
    const timer = setInterval(() => { void request<Status>('status').then(setStatus).catch(() => undefined) }, 700)
    return () => clearInterval(timer)
  }, [busy])
  const perform = async (path: string, body: unknown) => {
    if (!window.confirm(t('confirm'))) return
    setBusy(true); setOperationError('')
    try { await request(path, body); await load() } catch (e) { setOperationError(e instanceof Error ? e.message : String(e)) } finally { setBusy(false) }
  }
  return <section className={styles.root} aria-label={t('market')}>
    <header className={styles.header}><div><h2>{t('market')}</h2><p>{t('managed')}</p></div><button onClick={() => void load().catch(e => setError(String(e)))} disabled={busy}>{t('retry')}</button></header>
    {status.restartRequired && <p role="status" className={styles.notice}>{t('restart')}</p>}
    {busy && <p role="status" className={styles.notice}>{t(status.stage === 'checking' ? 'checking' : status.stage === 'authorizing' ? 'authorizing' : 'preparing')}</p>}
    {operationError && <p role="alert" className={styles.error}>{operationError}</p>}
    <h3>{t('installed')}</h3>
    <div className={styles.grid}>{installed.map(item => <article className={styles.card} key={item.id}><h4>{catalog?.plugins.find(p => p.id === item.id)?.name ?? item.id}</h4><p>{t('current')} {item.version}</p><button disabled={busy || status.restartRequired} onClick={() => void perform('uninstall', { id: item.id })}>{t('remove')}</button></article>)}</div>
    <h3>{t('available')}</h3>
    {error && <div role="alert" className={styles.error}><strong>{t('errorTitle')}</strong><p>{error}</p><p>{t('noFallback')}</p></div>}
    {catalog === null && !error && <p>{t('loading')}</p>}
    {catalog?.plugins.length === 0 && <p>{t('empty')}</p>}
    <div className={styles.grid}>{catalog?.plugins.map(item => {
      const current = installed.find(p => p.id === item.id), same = current?.version === item.version
      return <article className={styles.card} key={item.id}><span className={styles.category}>{item.category}</span><span className={styles.source}>{t(item.source === 'community' ? 'community' : 'owned')}</span><h4>{item.name}</h4><p>{item.description}</p><p>v{item.version}</p><button disabled={busy || status.restartRequired || same || !item.compatible} onClick={() => void perform(current ? 'update' : 'install', { id: item.id, version: item.version })}>{!item.compatible ? t('incompatible') : same ? t('installed') : t(current ? 'update' : 'install')}</button></article>
    })}</div>
    {catalog && <p className={styles.muted}>{t('revision')} {catalog.revision}</p>}
  </section>
}
export function ManagedModelsSection({ t }: { t: ManagedTranslate }) {
  const [data, setData] = useState<Models | null>(null), [key, setKey] = useState(''), [selected, setSelected] = useState('')
  const [message, setMessage] = useState(''), [error, setError] = useState(''), [busy, setBusy] = useState(false)
  const load = async () => { const data = await request<Models>('models'); setData(data); setSelected(data.selected) }
  useEffect(() => { void load().catch(e => setError(String(e))) }, [])
  const action = async (path: string, body: unknown, message: 'saved' | 'savedModel' | 'savedOk') => {
    setBusy(true); setError(''); setMessage('')
    try { await request(path, body); setKey(''); await load(); setMessage(t(message)) } catch (e) { setError(e instanceof Error ? e.message : String(e)) } finally { setBusy(false) }
  }
  return <section className={styles.root} aria-label={t('models')}><h2>{t('models')}</h2><p>{t('fixed')}</p>
    <p><strong>{t('site')}</strong> · <a href="https://model.codingrui.work" target="_blank" rel="noopener noreferrer">{t('account')}</a></p>
    {error && <p role="alert" className={styles.error}>{error}</p>}{message && <p role="status" className={styles.notice}>{message}</p>}
    <p>{data?.configured ? t('configured') : t('missing')}</p>
    {data?.writable === false && <p>{t('readonly')}</p>}
    <form onSubmit={event => { event.preventDefault(); void action('credential', { key }, 'saved') }}>
      <label>{t('key')}<input type="password" autoComplete="new-password" value={key} onChange={e => setKey(e.target.value)} disabled={busy || data?.writable === false} /></label>
      <button disabled={busy || key.trim().length === 0 || data?.writable === false}>{t('save')}</button>
    </form>
    <button disabled={busy || !data?.configured} onClick={() => void action('refresh-models', {}, 'savedOk')}>{t('refresh')}</button>
    {data && data.models.length > 0 ? <form onSubmit={event => { event.preventDefault(); void action('select-model', { model: selected }, 'savedModel') }}><label>{t('select')}<select value={selected} onChange={e => setSelected(e.target.value)}>{data.models.map(model => <option key={model.id} value={model.id}>{model.name}</option>)}</select></label><button disabled={busy || selected === ''}>{t('choose')}</button></form> : <p>{t('none')}</p>}
  </section>
}
