# 法律产品基础组件

`@lawyer-dsh/lawyer-platform` 由受管 `lawyer` profile 内置，提供固定本站的模型服务、个人凭据操作、已开放模型选择、市场所需的只读信任参数以及安装期间的任务准入限制。

- 模型站：`https://model.codingrui.work/v1`，provider 为 `lawyercopilot`，凭据引用为 `NEW_API_KEY`。
- `trust.json` 只含发布地址、公钥和兼容版本，不含签名私钥或模型令牌。
- 业务插件不默认全部启用，由市场选择安装。默认律师 preset 提供材料操作与提问；上游标准、PTC、极简、创造四种模式同时保留，可在新对话中选择。
- 创造模式可检查和编写插件草稿，但不能直接激活未经平台审核的动态插件；所有模式保持统一的模型站与市场规则。
- 文件夹选择使用配套的 browse Host/Client 两部分，避免 Web 产品依赖宿主原生文件对话框。
- 市场使用固定 pnpm 和私有 store；安装检查不复制用户的模型凭据。

本组件必须由包含进程级产品策略的 Harness 启动；不是一个可卸载、可替换模型站的普通业务插件。配置与上线方法见 `../../docs/managed-product.md`。
