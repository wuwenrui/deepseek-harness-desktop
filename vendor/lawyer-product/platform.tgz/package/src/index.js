/** Product-owned services. No endpoint, catalog source or signing key comes from user config. */
import { readFileSync } from 'node:fs'
import { join, dirname } from 'node:path'
import { createRequire } from 'node:module'
import { resolveDshHome } from '@deepseek-ai/dsh-home-paths'
import { LAWYER_PROVIDER, LAWYER_MODEL_URL, LAWYER_CREDENTIAL, isLawyerPolicyEnabled } from '@deepseek-ai/dsh-product-policy'

const require = createRequire(import.meta.url)
const trust = Object.freeze(JSON.parse(readFileSync(new URL('../trust.json', import.meta.url), 'utf8')))
export const name = 'lawyer-platform'
export const inject = ['llm', 'settings', 'credentials', 'agentDefaultModel', 'agents', 'webServer', 'loader', 'tools']

export function apply(ctx) {
  if (!isLawyerPolicyEnabled()) throw new Error('法律产品必须通过受管 lawyer profile 启动')
  const home = resolveDshHome()
  const desktop = ctx.get('lawyerDesktopRuntime')
  const profileDirectory = desktop?.profileDirectory ?? join(home, 'profiles', 'lawyer')
  const moduleFile = process.argv[1]
  if (!moduleFile && desktop === undefined) throw new Error('无法确定受管产品启动程序')
  let mutating = false
  ctx.on('agent/pre-step', (_request, next) => mutating ? Promise.resolve({ kind: 'reject' }) : next())
  const controller = {
    marketOptions() {
      return {
        catalogUrl: trust.catalogUrl,
        artifactOrigin: trust.artifactOrigin,
        publicKey: trust.publicKey,
        hostVersion: trust.hostVersion,
        profileDirectory,
        pnpm: desktop?.pnpm ?? { file: process.execPath, args: [join(dirname(require.resolve('pnpm')), require('pnpm').bin.pnpm)] },
        launcher: desktop?.launcher ?? { file: process.execPath, args: [...process.execArgv, moduleFile] },
        protectedPackages: ['@lawyer-dsh/lawyer-platform', '@lawyer-dsh/market', '@lawyer-dsh/lawyer-brand'],
        beginMutation() {
          if (mutating || controller.marketOptions().agentsBusy()) throw new Error('请先结束当前任务')
          mutating = true
          return () => { mutating = false }
        },
        agentsBusy() {
          const agents = ctx.agents.list()
          if (!Array.isArray(agents)) return true
          return agents.some(agent => !['idle', 'error', 'disposed'].includes(agent.status))
        },
      }
    },
    async modelStatus() {
      const credential = await ctx.credentials.describe(LAWYER_CREDENTIAL)
      const models = (await ctx.llm.listModels(LAWYER_PROVIDER)).map(model => ({ id: model.id, name: model.name ?? model.id }))
      const selection = ctx.agentDefaultModel.currentSelection()
      return { site: 'https://model.codingrui.work', configured: credential.configured, writable: credential.writable, models, selected: selection.model }
    },
    async saveCredential(value) {
      if (typeof value !== 'string' || value.trim().length === 0 || value.length > 2048 || /\s/.test(value)) throw new Error('令牌格式无效')
      await ctx.credentials.set(LAWYER_CREDENTIAL, value)
    },
    async refreshModels() {
      const found = await ctx.llm.discoverModels('llm-pi-ai', { provider: LAWYER_PROVIDER, baseURL: LAWYER_MODEL_URL, api: 'openai-completions' })
      if (!Array.isArray(found) || found.length === 0) throw new Error('本站未返回此账号可用的模型')
      const models = found.map(model => ({ id: model.id, name: model.name ?? model.id, ...(model.contextWindow === undefined ? {} : { contextWindow: model.contextWindow }), ...(model.maxTokens === undefined ? {} : { maxTokens: model.maxTokens }) }))
      await ctx.settings.update('llm-pi-ai', { providers: { [LAWYER_PROVIDER]: { models } } })
      const current = ctx.agentDefaultModel.currentSelection()
      if (!models.some(model => model.id === current.model)) await ctx.agentDefaultModel.saveSelection({ provider: LAWYER_PROVIDER, model: models[0].id })
      return controller.modelStatus()
    },
    async selectModel(id) {
      if (!(await ctx.llm.listModels(LAWYER_PROVIDER)).some(model => model.id === id)) throw new Error('只能选择本站已开放的模型')
      await ctx.agentDefaultModel.saveSelection({ provider: LAWYER_PROVIDER, model: id })
    },
  }
  ctx.provide('lawyerPlatform', Object.freeze(controller))
  let ready = false
  const appReady = ctx.get('appReady')
  if (!appReady) throw new Error('产品启动器未提供 readiness 服务')
  ctx.effect(() => appReady.onReady(() => { ready = true }))
  ctx.effect(() => ctx.webServer.register({ kind: 'exact', path: '/lawyer-platform/ready', handler(_request, response) {
    response.writeHead(ready ? 200 : 503, { 'content-type': 'application/json', 'cache-control': 'no-store' })
    response.end(JSON.stringify({ ready, product: 'lawyer', hostVersion: trust.hostVersion, tools: ctx.tools.schemas().map(tool => tool.name) }))
  } }))
}
