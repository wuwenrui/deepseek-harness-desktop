// 律师工作台品牌 bundle 的 host 半（Node 侧）。
// 品牌资产全部在 client 半（lib/client.js）；本模块存在的意义是让 profile Loader
// 能把本包作为普通 cordis 行挂载——bundle patch 自插入的 lawyer-brand 行同时是
// host 行与浏览器 roster 行——因此 apply 是空操作。
// 写法对齐函数插件约定：named-export name / apply，无 default export。

/** 插件名（与包名一致，便于 Loader 诊断信息辨认）。 */
export const name = '@lawyer-dsh/lawyer-brand'

/**
 * Host 侧不注册任何能力：品牌插槽与主题 token 都在浏览器侧生效，
 * 模型路由由 cordis.patch.yml 以配置层预置，无需运行时代码。
 * @param {object} _ctx - cordis 上下文（本插件不消费）。
 */
export function apply(_ctx) {}
