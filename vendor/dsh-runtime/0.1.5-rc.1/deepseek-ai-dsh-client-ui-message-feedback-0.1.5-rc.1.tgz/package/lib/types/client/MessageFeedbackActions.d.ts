/**
 * Per-message feedback controls: the Like/Dislike pair inside the assistant
 * message's IconActions row, between copy and branch. Like records at once
 * and raises the Session's acknowledgement toast; Dislike opens the Session's
 * feedback dialog, whose submission records the negative judgment with its
 * category and text. Clicking the recorded rating retracts it. A recorded
 * rating shows the filled glyph so the signal survives a pointer leaving the row.
 * @module @deepseek-ai/dsh-client-ui-message-feedback/client/MessageFeedbackActions
 */
import type { MessageFeedbackActionProps } from './slots.ts';
/**
 * One message's feedback controls.
 * @param props - the owner's message identity, the injected verbs, and the
 * shared feedback hook.
 * @returns the rating buttons with any failure notice beside them.
 */
export declare function MessageFeedbackActions({ messageId, ensure, current, toggle, openDialog, acknowledge, useFeedback, t, }: MessageFeedbackActionProps): import("react").JSX.Element;
//# sourceMappingURL=MessageFeedbackActions.d.ts.map